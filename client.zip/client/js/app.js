/**
 * TaskNest Application Controller
 * Handles DOM manipulation, event routing, state management, and user interaction
 */

(function () {
  'use strict';

  // --- Application State ---
  const state = {
    tasks: [],
    stats: { total: 0, pending: 0, completed: 0 },
    currentFilter: 'all',          // 'all' | 'pending' | 'completed'
    currentPriority: 'all',        // 'all' | 'Low' | 'Medium' | 'High'
    searchQuery: '',
    sortBy: 'createdAt',
    order: 'desc',
    activeDeletingTask: null,
    searchDebounceTimer: null
  };

  // --- DOM Elements Cache ---
  const elements = {
    // Server status
    serverStatus: document.getElementById('server-status'),
    statusDot: document.getElementById('status-dot'),
    statusText: document.getElementById('status-text'),

    // Statistics
    statTotal: document.getElementById('stat-total'),
    statPending: document.getElementById('stat-pending'),
    statCompleted: document.getElementById('stat-completed'),
    statRate: document.getElementById('stat-rate'),
    progressFill: document.getElementById('progress-fill'),

    // Add Task Form
    addTaskForm: document.getElementById('add-task-form'),
    taskTitleInput: document.getElementById('task-title'),
    titleFeedback: document.getElementById('title-feedback'),
    taskDueDateInput: document.getElementById('task-due-date'),
    taskDescInput: document.getElementById('task-description'),
    btnAddTask: document.getElementById('btn-add-task'),
    addSpinner: document.getElementById('add-spinner'),

    // Filters and Search Toolbar
    searchInput: document.getElementById('search-input'),
    btnClearSearch: document.getElementById('btn-clear-search'),
    priorityFilter: document.getElementById('priority-filter'),
    sortBySelect: document.getElementById('sort-by'),
    filterTabs: document.querySelectorAll('.tab-btn'),
    activeFilterText: document.getElementById('active-filter-text'),
    tabBadgeAll: document.getElementById('tab-badge-all'),
    tabBadgePending: document.getElementById('tab-badge-pending'),
    tabBadgeCompleted: document.getElementById('tab-badge-completed'),

    // Tasks Containers
    tasksContainer: document.getElementById('tasks-container'),
    loadingState: document.getElementById('loading-state'),
    emptyState: document.getElementById('empty-state'),
    emptyTitle: document.getElementById('empty-title'),
    emptySubtitle: document.getElementById('empty-subtitle'),

    // Edit Modal
    editModal: document.getElementById('edit-modal'),
    editTaskForm: document.getElementById('edit-task-form'),
    editTaskId: document.getElementById('edit-task-id'),
    editTaskTitle: document.getElementById('edit-task-title'),
    editTitleFeedback: document.getElementById('edit-title-feedback'),
    editTaskDueDate: document.getElementById('edit-task-due-date'),
    editTaskDesc: document.getElementById('edit-task-description'),
    editTaskCompleted: document.getElementById('edit-task-completed'),
    btnCloseEditModal: document.getElementById('btn-close-edit-modal'),
    btnCancelEdit: document.getElementById('btn-cancel-edit'),
    btnSaveEdit: document.getElementById('btn-save-edit'),
    editSpinner: document.getElementById('edit-spinner'),

    // Delete Modal
    deleteModal: document.getElementById('delete-modal'),
    deleteTaskTitlePreview: document.getElementById('delete-task-title-preview'),
    btnCancelDelete: document.getElementById('btn-cancel-delete'),
    btnConfirmDelete: document.getElementById('btn-confirm-delete'),
    deleteSpinner: document.getElementById('delete-spinner'),

    // Toast Container
    toastContainer: document.getElementById('toast-container')
  };

  // --- Utility Functions ---

  /**
   * Escape HTML to prevent XSS attacks
   * @param {string} str 
   * @returns {string}
   */
  const escapeHTML = (str) => {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };

  /**
   * Format date for due date badges
   * @param {string|Date} dateStr 
   * @param {boolean} isCompleted 
   * @returns {{label: string, className: string}}
   */
  const formatDueDate = (dateStr, isCompleted) => {
    if (!dateStr) return null;

    const dueDate = new Date(dateStr);
    if (isNaN(dueDate.getTime())) return null;

    // Normalise to midnight for accurate day comparison
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const target = new Date(dueDate.getFullYear(), dueDate.getMonth(), dueDate.getDate());

    const diffDays = Math.round((target - today) / (1000 * 60 * 60 * 24));

    const options = { month: 'short', day: 'numeric', year: target.getFullYear() !== today.getFullYear() ? 'numeric' : undefined };
    const dateFormatted = target.toLocaleDateString(undefined, options);

    if (isCompleted) {
      return {
        label: `Due ${dateFormatted}`,
        className: 'badge-due-future'
      };
    }

    if (diffDays < 0) {
      const overdueDays = Math.abs(diffDays);
      return {
        label: `Overdue (${overdueDays}d ago)`,
        className: 'badge-due-overdue'
      };
    } else if (diffDays === 0) {
      return {
        label: 'Due Today',
        className: 'badge-due-today'
      };
    } else if (diffDays === 1) {
      return {
        label: 'Due Tomorrow',
        className: 'badge-due-today'
      };
    } else {
      return {
        label: `Due ${dateFormatted}`,
        className: 'badge-due-future'
      };
    }
  };

  /**
   * Format relative creation date (e.g. "Just now", "2h ago", "Nov 11")
   * @param {string|Date} dateStr 
   * @returns {string}
   */
  const formatCreatedAt = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '';

    const now = new Date();
    const diffSeconds = Math.floor((now - date) / 1000);

    if (diffSeconds < 60) return 'Just now';
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays}d ago`;

    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  // --- Toast Notifications System ---

  /**
   * Display a floating toast notification
   * @param {string} message 
   * @param {'success'|'error'|'info'} [type='success'] 
   */
  const showToast = (message, type = 'success') => {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`;
    } else if (type === 'error') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`;
    } else {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
    }

    toast.innerHTML = `
      ${iconSvg}
      <span class="toast-message">${escapeHTML(message)}</span>
      <button class="toast-close" aria-label="Close notification">&times;</button>
    `;

    elements.toastContainer.appendChild(toast);

    const removeToast = () => {
      toast.classList.add('toast-hiding');
      setTimeout(() => {
        if (toast.parentElement) {
          toast.remove();
        }
      }, 250);
    };

    toast.querySelector('.toast-close').addEventListener('click', removeToast);
    setTimeout(removeToast, 3500);
  };

  // --- UI Update & Rendering ---

  /**
   * Update the statistics numbers and progress bar
   * @param {{total: number, pending: number, completed: number}} stats 
   */
  const updateStats = (stats) => {
    state.stats = stats;
    elements.statTotal.textContent = stats.total;
    elements.statPending.textContent = stats.pending;
    elements.statCompleted.textContent = stats.completed;

    elements.tabBadgeAll.textContent = stats.total;
    elements.tabBadgePending.textContent = stats.pending;
    elements.tabBadgeCompleted.textContent = stats.completed;

    const rate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
    elements.statRate.textContent = `${rate}%`;
    elements.progressFill.style.width = `${rate}%`;
  };

  /**
   * Render the task cards into the DOM
   * @param {Array} tasks 
   */
  const renderTasks = (tasks) => {
    elements.tasksContainer.innerHTML = '';

    if (!tasks || tasks.length === 0) {
      elements.emptyState.classList.remove('hidden');

      if (state.searchQuery || state.currentFilter !== 'all' || state.currentPriority !== 'all') {
        elements.emptyTitle.textContent = 'No matching tasks found';
        elements.emptySubtitle.textContent = 'Try clearing your search query or adjusting your filters to see more tasks.';
      } else {
        elements.emptyTitle.textContent = 'Your Nest is Empty';
        elements.emptySubtitle.textContent = 'Create your first task using the form on the left to start organizing!';
      }
      return;
    }

    elements.emptyState.classList.add('hidden');

    const fragment = document.createDocumentFragment();

    tasks.forEach((task) => {
      const card = document.createElement('article');
      card.className = `task-card priority-${task.priority} ${task.completed ? 'is-completed' : ''}`;
      card.setAttribute('data-id', task._id);
      card.setAttribute('role', 'listitem');

      const dueInfo = formatDueDate(task.dueDate, task.completed);
      const createdText = formatCreatedAt(task.createdAt);

      card.innerHTML = `
        <!-- Checkbox Toggle -->
        <button
          type="button"
          class="task-check-btn"
          aria-label="${task.completed ? 'Mark task as pending' : 'Mark task as completed'}"
          title="${task.completed ? 'Mark as pending' : 'Mark as completed'}"
          data-action="toggle-complete"
          data-id="${task._id}"
        >
          <div class="check-circle">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
          </div>
        </button>

        <!-- Task Content -->
        <div class="task-content">
          <div class="task-main-row">
            <h3 class="task-title">${escapeHTML(task.title)}</h3>
          </div>

          <div class="task-meta">
            <!-- Priority Badge -->
            <span class="badge-priority badge-${task.priority.toLowerCase()}">
              <span class="dot dot-${task.priority.toLowerCase()}"></span>
              ${task.priority} Priority
            </span>

            <!-- Status Badge if Completed -->
            ${task.completed ? `
              <span class="badge-status-completed">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                Completed
              </span>
            ` : ''}

            <!-- Due Date Badge -->
            ${dueInfo ? `
              <span class="badge-due ${dueInfo.className}">
                ${escapeHTML(dueInfo.label)}
              </span>
            ` : ''}

            <!-- Created Time -->
            ${createdText ? `<span class="badge-created">${escapeHTML(createdText)}</span>` : ''}
          </div>

          <!-- Description (if provided) -->
          ${task.description ? `<p class="task-description">${escapeHTML(task.description)}</p>` : ''}
        </div>

        <!-- Task Actions -->
        <div class="task-actions">
          <button
            type="button"
            class="action-btn action-btn-edit"
            data-action="edit"
            data-id="${task._id}"
            title="Edit task"
            aria-label="Edit task"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button
            type="button"
            class="action-btn action-btn-delete"
            data-action="delete"
            data-id="${task._id}"
            title="Delete task"
            aria-label="Delete task"
          >
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      `;

      fragment.appendChild(card);
    });

    elements.tasksContainer.appendChild(fragment);
  };

  /**
   * Update active filter descriptive text
   */
  const updateFilterIndicator = () => {
    const parts = [];
    if (state.currentFilter === 'all') {
      parts.push('Showing all tasks');
    } else if (state.currentFilter === 'pending') {
      parts.push('Showing pending tasks');
    } else if (state.currentFilter === 'completed') {
      parts.push('Showing completed tasks');
    }

    if (state.currentPriority !== 'all') {
      parts.push(`with ${state.currentPriority} priority`);
    }

    if (state.searchQuery) {
      parts.push(`matching "${state.searchQuery}"`);
    }

    elements.activeFilterText.textContent = parts.join(' ');
  };

  // --- API Integrations & Data Loading ---

  /**
   * Load tasks from backend MongoDB REST API
   * @param {boolean} [showSkeleton=true] 
   */
  const loadTasks = async (showSkeleton = true) => {
    if (showSkeleton) {
      elements.loadingState.classList.remove('hidden');
      elements.emptyState.classList.add('hidden');
    }

    try {
      const [sortBy, order] = elements.sortBySelect.value.split('-');

      const params = {
        status: state.currentFilter,
        priority: state.currentPriority,
        search: state.searchQuery,
        sortBy,
        order
      };

      const response = await window.TaskAPI.getTasks(params);

      state.tasks = response.data || [];
      if (response.stats) {
        updateStats(response.stats);
      }

      renderTasks(state.tasks);
      updateFilterIndicator();
    } catch (error) {
      console.error('Failed to load tasks from MongoDB:', error);
      showToast(error.message || 'Could not connect to MongoDB database.', 'error');
      elements.emptyTitle.textContent = 'Connection Error';
      elements.emptySubtitle.textContent = 'Failed to load tasks from server. Ensure Express backend is running and MongoDB is connected.';
      elements.emptyState.classList.remove('hidden');
    } finally {
      elements.loadingState.classList.add('hidden');
    }
  };

  /**
   * Check API Server & MongoDB Connection status
   * Accurately distinguishes:
   *  - MongoDB Atlas Connected
   *  - In-Memory Database
   *  - Database Disconnected
   */
  const checkServerStatus = async () => {
    try {
      const health = await window.TaskAPI.checkHealth();
      const db = health.database || {};

      if (!db.connected || db.type === 'disconnected') {
        elements.statusDot.className = 'status-dot error';
        elements.statusText.textContent = 'Database Disconnected';
        elements.serverStatus.setAttribute('title', 'Database is disconnected. Please check server logs and .env configuration.');
      } else if (db.type === 'atlas') {
        elements.statusDot.className = 'status-dot connected';
        elements.statusText.textContent = 'MongoDB Atlas Connected';
        elements.serverStatus.setAttribute('title', `Connected to MongoDB Atlas cluster: ${db.host} (DB: ${db.database})`);
      } else if (db.type === 'memory') {
        elements.statusDot.className = 'status-dot memory';
        elements.statusText.textContent = 'In-Memory Database';
        elements.serverStatus.setAttribute('title', 'Running in ephemeral in-memory mode. Tasks will not persist across restarts. Configure MONGODB_URI in .env for Atlas storage.');
      } else {
        elements.statusDot.className = 'status-dot connected';
        elements.statusText.textContent = db.label || 'MongoDB Connected';
        elements.serverStatus.setAttribute('title', `Database: ${db.database} on ${db.host}`);
      }
    } catch (err) {
      elements.statusDot.className = 'status-dot error';
      elements.statusText.textContent = 'Database Disconnected';
      elements.serverStatus.setAttribute('title', 'Cannot reach backend server. Please check your network or restart Express.');
    }
  };

  // --- Form & Action Handlers ---

  /**
   * Handle Add Task Form Submission
   * @param {Event} e 
   */
  const handleAddTask = async (e) => {
    e.preventDefault();

    const title = elements.taskTitleInput.value.trim();
    if (!title) {
      elements.taskTitleInput.classList.add('is-invalid');
      elements.titleFeedback.textContent = 'Please enter a task title.';
      elements.titleFeedback.classList.add('show');
      elements.taskTitleInput.focus();
      return;
    }

    // Clear validation error
    elements.taskTitleInput.classList.remove('is-invalid');
    elements.titleFeedback.classList.remove('show');

    // Selected priority radio
    const priorityRadio = elements.addTaskForm.querySelector('input[name="priority"]:checked');
    const priority = priorityRadio ? priorityRadio.value : 'Medium';
    const dueDate = elements.taskDueDateInput.value || null;
    const description = elements.taskDescInput.value.trim();

    // Disable button and show spinner
    elements.btnAddTask.disabled = true;
    elements.addSpinner.classList.remove('hidden');

    try {
      const response = await window.TaskAPI.createTask({
        title,
        description,
        priority,
        dueDate
      });

      showToast('Task added successfully to TaskNest! 🎯', 'success');

      // Reset form
      elements.addTaskForm.reset();
      // Reset priority to Medium default
      const medRadio = elements.addTaskForm.querySelector('input[name="priority"][value="Medium"]');
      if (medRadio) medRadio.checked = true;

      // Reload tasks to refresh list and statistics from MongoDB
      await loadTasks(false);
    } catch (error) {
      console.error('Create Task Error:', error);
      showToast(error.message || 'Failed to create task in MongoDB.', 'error');
    } finally {
      elements.btnAddTask.disabled = false;
      elements.addSpinner.classList.add('hidden');
    }
  };

  /**
   * Toggle task completion status
   * @param {string} id 
   */
  const handleToggleComplete = async (id) => {
    const taskIndex = state.tasks.findIndex((t) => t._id === id);
    if (taskIndex === -1) return;

    const task = state.tasks[taskIndex];
    const newCompleted = !task.completed;

    try {
      const response = await window.TaskAPI.toggleTaskCompletion(id, newCompleted);
      const updatedTask = response.data;

      showToast(
        updatedTask.completed ? 'Task marked as completed! 🎉' : 'Task marked as pending.',
        'success'
      );

      // Refresh list to update counts and filters
      await loadTasks(false);
    } catch (error) {
      console.error('Toggle completion error:', error);
      showToast(error.message || 'Failed to update task completion.', 'error');
    }
  };

  // --- Edit Task Modal Handlers ---

  /**
   * Open the Edit Modal with preloaded task values
   * @param {string} id 
   */
  const openEditModal = (id) => {
    const task = state.tasks.find((t) => t._id === id);
    if (!task) return;

    elements.editTaskId.value = task._id;
    elements.editTaskTitle.value = task.title;
    elements.editTaskTitle.classList.remove('is-invalid');
    elements.editTitleFeedback.classList.remove('show');

    // Due date
    if (task.dueDate) {
      const d = new Date(task.dueDate);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      elements.editTaskDueDate.value = `${yyyy}-${mm}-${dd}`;
    } else {
      elements.editTaskDueDate.value = '';
    }

    elements.editTaskDesc.value = task.description || '';
    elements.editTaskCompleted.checked = Boolean(task.completed);

    // Set Priority radio
    const prioRadio = elements.editTaskForm.querySelector(`input[name="edit-priority"][value="${task.priority}"]`);
    if (prioRadio) {
      prioRadio.checked = true;
    }

    elements.editModal.classList.remove('hidden');
    elements.editTaskTitle.focus();
  };

  /**
   * Close the Edit Modal
   */
  const closeEditModal = () => {
    elements.editModal.classList.add('hidden');
    elements.editTaskForm.reset();
  };

  /**
   * Handle Save Changes in Edit Modal
   * @param {Event} e 
   */
  const handleSaveEdit = async (e) => {
    e.preventDefault();

    const id = elements.editTaskId.value;
    const title = elements.editTaskTitle.value.trim();

    if (!title) {
      elements.editTaskTitle.classList.add('is-invalid');
      elements.editTitleFeedback.textContent = 'Task title cannot be empty.';
      elements.editTitleFeedback.classList.add('show');
      elements.editTaskTitle.focus();
      return;
    }

    elements.editTaskTitle.classList.remove('is-invalid');
    elements.editTitleFeedback.classList.remove('show');

    const prioRadio = elements.editTaskForm.querySelector('input[name="edit-priority"]:checked');
    const priority = prioRadio ? prioRadio.value : 'Medium';
    const dueDate = elements.editTaskDueDate.value || null;
    const description = elements.editTaskDesc.value.trim();
    const completed = elements.editTaskCompleted.checked;

    elements.btnSaveEdit.disabled = true;
    elements.editSpinner.classList.remove('hidden');

    try {
      await window.TaskAPI.updateTask(id, {
        title,
        description,
        priority,
        dueDate,
        completed
      });

      showToast('Task updated successfully! ✏️', 'success');
      closeEditModal();
      await loadTasks(false);
    } catch (error) {
      console.error('Update Task Error:', error);
      showToast(error.message || 'Failed to update task in MongoDB.', 'error');
    } finally {
      elements.btnSaveEdit.disabled = false;
      elements.editSpinner.classList.add('hidden');
    }
  };

  // --- Delete Task Modal Handlers ---

  /**
   * Open Delete Confirmation Modal
   * @param {string} id 
   */
  const openDeleteModal = (id) => {
    const task = state.tasks.find((t) => t._id === id);
    if (!task) return;

    state.activeDeletingTask = task;
    elements.deleteTaskTitlePreview.textContent = `"${task.title}"`;
    elements.deleteModal.classList.remove('hidden');
    elements.btnConfirmDelete.focus();
  };

  /**
   * Close Delete Confirmation Modal
   */
  const closeDeleteModal = () => {
    elements.deleteModal.classList.add('hidden');
    state.activeDeletingTask = null;
  };

  /**
   * Confirm Delete Task from MongoDB
   */
  const handleConfirmDelete = async () => {
    if (!state.activeDeletingTask) return;

    const id = state.activeDeletingTask._id;
    elements.btnConfirmDelete.disabled = true;
    elements.deleteSpinner.classList.remove('hidden');

    try {
      await window.TaskAPI.deleteTask(id);
      showToast('Task deleted from MongoDB successfully. 🗑️', 'info');
      closeDeleteModal();
      await loadTasks(false);
    } catch (error) {
      console.error('Delete Task Error:', error);
      showToast(error.message || 'Failed to delete task from MongoDB.', 'error');
    } finally {
      elements.btnConfirmDelete.disabled = false;
      elements.deleteSpinner.classList.add('hidden');
    }
  };

  // --- Event Delegations & Listeners ---

  const initEventListeners = () => {
    // Add Task Form Submit
    elements.addTaskForm.addEventListener('submit', handleAddTask);

    // Input validation cleanup on typing
    elements.taskTitleInput.addEventListener('input', () => {
      if (elements.taskTitleInput.value.trim().length > 0) {
        elements.taskTitleInput.classList.remove('is-invalid');
        elements.titleFeedback.classList.remove('show');
      }
    });

    // Task Card delegation (toggle complete, edit, delete)
    elements.tasksContainer.addEventListener('click', (e) => {
      const toggleBtn = e.target.closest('[data-action="toggle-complete"]');
      if (toggleBtn) {
        const id = toggleBtn.getAttribute('data-id');
        handleToggleComplete(id);
        return;
      }

      const editBtn = e.target.closest('[data-action="edit"]');
      if (editBtn) {
        const id = editBtn.getAttribute('data-id');
        openEditModal(id);
        return;
      }

      const deleteBtn = e.target.closest('[data-action="delete"]');
      if (deleteBtn) {
        const id = deleteBtn.getAttribute('data-id');
        openDeleteModal(id);
        return;
      }
    });

    // Filter Tabs (All, Pending, Completed)
    elements.filterTabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        elements.filterTabs.forEach((t) => {
          t.classList.remove('active');
          t.setAttribute('aria-selected', 'false');
        });
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');

        state.currentFilter = tab.getAttribute('data-filter');
        loadTasks();
      });
    });

    // Priority Dropdown Filter
    elements.priorityFilter.addEventListener('change', () => {
      state.currentPriority = elements.priorityFilter.value;
      loadTasks();
    });

    // Sort By Dropdown
    elements.sortBySelect.addEventListener('change', () => {
      loadTasks();
    });

    // Search Input with Debounce
    elements.searchInput.addEventListener('input', (e) => {
      const val = e.target.value;
      state.searchQuery = val;

      if (val.trim()) {
        elements.btnClearSearch.classList.remove('hidden');
      } else {
        elements.btnClearSearch.classList.add('hidden');
      }

      clearTimeout(state.searchDebounceTimer);
      state.searchDebounceTimer = setTimeout(() => {
        loadTasks(false);
      }, 250);
    });

    // Clear Search Button
    elements.btnClearSearch.addEventListener('click', () => {
      elements.searchInput.value = '';
      state.searchQuery = '';
      elements.btnClearSearch.classList.add('hidden');
      loadTasks(false);
      elements.searchInput.focus();
    });

    // Edit Modal Buttons & Form
    elements.editTaskForm.addEventListener('submit', handleSaveEdit);
    elements.btnCloseEditModal.addEventListener('click', closeEditModal);
    elements.btnCancelEdit.addEventListener('click', closeEditModal);

    // Delete Modal Buttons
    elements.btnCancelDelete.addEventListener('click', closeDeleteModal);
    elements.btnConfirmDelete.addEventListener('click', handleConfirmDelete);

    // Close modals on clicking backdrop overlay
    elements.editModal.addEventListener('click', (e) => {
      if (e.target === elements.editModal) closeEditModal();
    });
    elements.deleteModal.addEventListener('click', (e) => {
      if (e.target === elements.deleteModal) closeDeleteModal();
    });

    // Keyboard support: Escape closes modals
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (!elements.editModal.classList.contains('hidden')) {
          closeEditModal();
        }
        if (!elements.deleteModal.classList.contains('hidden')) {
          closeDeleteModal();
        }
      }
    });
  };

  // --- Application Initialisation ---
  const init = async () => {
    initEventListeners();
    await checkServerStatus();
    await loadTasks(true);

    // Periodically recheck connection status
    setInterval(checkServerStatus, 15000);
  };

  // Run on DOM Ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
