/**
 * TaskNest API Client
 * Encapsulates all backend REST API requests using standard fetch()
 */

// Dynamically determine API Base URL
// - If served from Express backend (on any port), use relative path '/api/tasks'
// - If opened via Live Server (e.g. port 5500, 3000) or file://, talk to default backend at 'http://localhost:5000/api/tasks'
const getApiBaseUrl = () => {
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol;
    const port = window.location.port;

    if (protocol === 'file:' || port === '5500' || port === '3000') {
      return 'http://localhost:5000/api/tasks';
    }
    // Same-origin relative path for all Express served environments
    return '/api/tasks';
  }
  return '/api/tasks';
};

const API_BASE = getApiBaseUrl();

/**
 * Helper to handle fetch responses and parse JSON errors
 * @param {Response} response 
 * @returns {Promise<any>}
 */
const handleResponse = async (response) => {
  let data;
  const contentType = response.headers.get('content-type');
  
  if (contentType && contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = { error: await response.text() };
  }

  if (!response.ok) {
    const errorMessage = data && data.error ? data.error : `Request failed with status ${response.status}`;
    const error = new Error(errorMessage);
    error.status = response.status;
    error.data = data;
    throw error;
  }

  return data;
};

const TaskAPI = {
  /**
   * Fetch all tasks with optional search, filter, and sorting
   * @param {Object} [params] - Query options: { status, priority, search, sortBy, order }
   * @returns {Promise<{success: boolean, count: number, stats: Object, data: Array}>}
   */
  async getTasks(params = {}) {
    const query = new URLSearchParams();

    if (params.status && params.status !== 'all') {
      query.append('status', params.status);
    }
    if (params.priority && params.priority !== 'all') {
      query.append('priority', params.priority);
    }
    if (params.search && params.search.trim()) {
      query.append('search', params.search.trim());
    }
    if (params.sortBy) {
      query.append('sortBy', params.sortBy);
    }
    if (params.order) {
      query.append('order', params.order);
    }

    const queryString = query.toString();
    const url = queryString ? `${API_BASE}?${queryString}` : API_BASE;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    return handleResponse(response);
  },

  /**
   * Fetch a single task by its MongoDB ObjectId
   * @param {string} id 
   * @returns {Promise<{success: boolean, data: Object}>}
   */
  async getTaskById(id) {
    const response = await fetch(`${API_BASE}/${id}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      }
    });

    return handleResponse(response);
  },

  /**
   * Create a new task in MongoDB
   * @param {Object} taskData - { title, description, priority, dueDate }
   * @returns {Promise<{success: boolean, message: string, data: Object}>}
   */
  async createTask(taskData) {
    const response = await fetch(API_BASE, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(taskData)
    });

    return handleResponse(response);
  },

  /**
   * Update an existing task in MongoDB
   * @param {string} id 
   * @param {Object} taskData - { title, description, priority, dueDate, completed }
   * @returns {Promise<{success: boolean, message: string, data: Object}>}
   */
  async updateTask(id, taskData) {
    const response = await fetch(`${API_BASE}/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(taskData)
    });

    return handleResponse(response);
  },

  /**
   * Toggle task completion status
   * @param {string} id 
   * @param {boolean} [completed] - Optional explicit boolean value
   * @returns {Promise<{success: boolean, message: string, data: Object}>}
   */
  async toggleTaskCompletion(id, completed) {
    const body = typeof completed === 'boolean' ? JSON.stringify({ completed }) : JSON.stringify({});

    const response = await fetch(`${API_BASE}/${id}/complete`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body
    });

    return handleResponse(response);
  },

  /**
   * Delete a task from MongoDB
   * @param {string} id 
   * @returns {Promise<{success: boolean, message: string, data: Object}>}
   */
  async deleteTask(id) {
    const response = await fetch(`${API_BASE}/${id}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json'
      }
    });

    return handleResponse(response);
  },

  /**
   * Check backend API health
   * @returns {Promise<{status: string, service: string}>}
   */
  async checkHealth() {
    const healthUrl = API_BASE.replace('/api/tasks', '/api/health');
    const response = await fetch(healthUrl, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    return handleResponse(response);
  }
};

// Export for browser global scope
window.TaskAPI = TaskAPI;
