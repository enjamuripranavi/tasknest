const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const mongoose = require('mongoose');

// Load env files early (both root and server folder)
dotenv.config({ path: path.resolve(__dirname, '../../.env') }); // root .env (project root)
dotenv.config({ path: path.resolve(__dirname, '../../../.env') }); // server/.env (just in case)

/**
 * Redact passwords in logs.
 */
const sanitizeMessage = (str) => {
  if (!str || typeof str !== 'string') return '';
  return str.replace(/(mongodb(?:\+srv)?:\/\/[^:]+:)([^@]+)(@)/gi, '$1****$3');
};

/**
 * Validate that a string looks like a real MongoDB URI (not a placeholder).
 */
const isValidMongoURI = (str) => {
  if (!str || typeof str !== 'string') return false;
  let s = str.trim();
  s = s.replace(/^['"`]|['"`]$/g, '').trim();
  s = s.replace(/^(?:export\s+|set\s+)?MONGODB_URI\s*=\s*/, '').trim();
  if (
    s.includes('PASTE_YOUR_') ||
    s.includes('your_mongodb_atlas_connection_string') ||
    s.includes('<username>') ||
    s.includes('<password>')
  ) {
    return false;
  }
  return s.startsWith('mongodb://') || s.startsWith('mongodb+srv://');
};

/**
 * Normalize a raw URI string:
 *   - Strip surrounding quotes / variable prefixes.
 *   - Ensure the database is `/tasknest`.
 *   - Encode passwords that contain unsafe characters (including `@`).
 */
const normalizeMongoURI = (str) => {
  if (!str || typeof str !== 'string') return '';
  let s = str.trim();
  s = s.replace(/^(?:export\s+|set\s+)?MONGODB_URI\s*=\s*/, '').trim();
  s = s.replace(/^['"`]|['"`]$/g, '').trim();

  // If the user pasted a full command, extract the URI part.
  const cmdMatch = s.match(/mongodb(?:\+srv)?:\/\/[^\s'"`]+/);
  if (cmdMatch) s = cmdMatch[0];

  // Force the database name to be `tasknest`.
  const dbRegex = /^((?:mongodb(?:\+srv)?):\/\/[^\/\?]+)(?:\/[^\?]*)?(\?.*)?$/;
  const dbMatch = s.match(dbRegex);
  if (dbMatch) {
    const cluster = dbMatch[1];
    const query = dbMatch[2] || '?retryWrites=true\\u0026w=majority';
    s = `${cluster}/tasknest${query}`;
  }

  // Robust credential handling – split at the LAST '@' before the first '/'
  const protoMatch = s.match(/^(mongodb(?:\+srv)?:\/\/)/);
  if (protoMatch) {
    const protocol = protoMatch[1];
    const remainder = s.slice(protocol.length);
    const slashIdx = remainder.indexOf('/');
    const atIdx = remainder.lastIndexOf('@', slashIdx === -1 ? undefined : slashIdx);
    if (atIdx !== -1) {
      const credPart = remainder.slice(0, atIdx); // username:password
      const hostPart = remainder.slice(atIdx + 1); // host and path
      const colonIdx = credPart.indexOf(':');
      if (colonIdx !== -1) {
        const username = credPart.slice(0, colonIdx);
        const rawPassword = credPart.slice(colonIdx + 1);
        const encodedPassword = /^[A-Za-z0-9%._-]+$/.test(rawPassword)
          ? rawPassword
          : encodeURIComponent(rawPassword);
        s = `${protocol}${username}:${encodedPassword}@${hostPart}`;
      }
    }
  }

  return s;
};

/**
 * Resolve MONGODB_URI from environment variables or .env files.
 */
const resolveMongoURI = () => {
  const possiblePaths = [
    path.resolve(__dirname, '../../.env'),       // root .env
    path.resolve(__dirname, '../../../.env'),    // server/.env (in case of different cwd)
    path.resolve(process.cwd(), '.env'),
    path.resolve(process.cwd(), 'server/.env')
  ];

  // 1. Direct env variable
  if (isValidMongoURI(process.env.MONGODB_URI)) {
    const cleaned = normalizeMongoURI(process.env.MONGODB_URI);
    process.env.MONGODB_URI = cleaned;
    return cleaned;
  }

  // 2. Scan .env files
  for (const envPath of possiblePaths) {
    if (fs.existsSync(envPath)) {
      try {
        const raw = fs.readFileSync(envPath, 'utf8');
        const parsed = dotenv.parse(raw);
        if (parsed.MONGODB_URI && isValidMongoURI(parsed.MONGODB_URI)) {
          const cleaned = normalizeMongoURI(parsed.MONGODB_URI);
          process.env.MONGODB_URI = cleaned;
          // copy any other vars (but don’t overwrite real values)
          Object.keys(parsed).forEach((k) => {
            if (!process.env[k] || process.env[k].includes('PASTE_YOUR_')) {
              process.env[k] = parsed[k];
            }
          });
          return cleaned;
        }
      } catch (e) {
        // ignore and continue
      }
    }
  }
  return null;
};

/**
 * Connect to MongoDB Atlas using the resolved URI.
 */
const connectDB = async () => {
  const uri = resolveMongoURI();
  if (!uri) {
    console.error('\n' + '='.repeat(70));
    console.error('❌ MONGODB_URI NOT CONFIGURED');
    console.error('='.repeat(70));
    console.error('TaskNest requires your MongoDB Atlas connection string for permanent storage.');
    console.error('No active MONGODB_URI found in .env files.');
    console.error('Please run `npm run config-db` to set it.');
    console.error('='.repeat(70) + '\n');
    throw new Error('MONGODB_URI is required');
  }

  const isAtlas = uri.includes('mongodb.net');
  try {
    console.log(`\n⏳ Connecting to MongoDB ${isAtlas ? 'Atlas' : 'instance'}...`);
    const conn = await mongoose.connect(uri, {
      dbName: 'tasknest',
      serverSelectionTimeoutMS: 10000,
      autoIndex: true
    });
    console.log('\n' + '='.repeat(70));
    console.log(`✅ MongoDB ${isAtlas ? 'Atlas' : ''} Connected Successfully!`);
    console.log(`   Cluster Host   : ${conn.connection.host}`);
    console.log(`   Target Database: ${conn.connection.name}`);
    console.log('='.repeat(70) + '\n');
    return conn;
  } catch (err) {
    console.error('\n' + '='.repeat(70));
    console.error('❌ MONGODB ATLAS CONNECTION FAILED');
    console.error('='.repeat(70));
    console.error(`Error Details: ${sanitizeMessage(err.message)}`);
    throw err;
  }
};

/**
 * Disconnect cleanly.
 */
const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
  } catch (e) {
    console.error('Error disconnecting from MongoDB:', e.message);
  }
};

/**
 * Return connection status for health checks.
 */
const getDatabaseInfo = () => {
  const ready = mongoose.connection.readyState; // 0=disconnected,1=connected
  if (ready !== 1) {
    return { connected: false, type: 'disconnected', label: 'Database Disconnected', host: null, database: null };
  }
  const uri = process.env.MONGODB_URI || '';
  const isAtlas = uri.includes('mongodb.net');
  return {
    connected: true,
    type: isAtlas ? 'atlas' : 'local',
    label: isAtlas ? 'MongoDB Atlas Connected' : 'Local MongoDB Connected',
    host: mongoose.connection.host,
    database: mongoose.connection.name
  };
};

module.exports = { connectDB, disconnectDB, getDatabaseInfo, resolveMongoURI, isValidMongoURI };
