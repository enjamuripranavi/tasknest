const mongoose = require('mongoose');
const Task = require('../models/Task');

/**
 * Validate MongoDB ObjectId format
 * @param {string} id 
 * @returns {boolean}
 */
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

/**
 * @desc    Get all tasks with optional search, filter, and sorting
 * @route   GET /api/tasks
 * @access  Public
 */
const getTasks = async (req, res, next) => {
  try {
    const { status, priority, search, sortBy = 'createdAt', order = 'desc' } = req.query;

    const query = {};

    // Filter by completion status
    if (status === 'completed') {
      query.completed = true;
    } else if (status === 'pending') {
      query.completed = false;
    }

    // Filter by priority
    if (priority && ['Low', 'Medium', 'High'].includes(priority)) {
      query.priority = priority;
    }

    // Search by title or description (case-insensitive regex)
    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [{ title: searchRegex }, { description: searchRegex }];
    }

    // Determine sorting
    const sortField = ['createdAt', 'dueDate', 'title', 'priority'].includes(sortBy)
      ? sortBy
      : 'createdAt';
    const sortDirection = order === 'asc' ? 1 : -1;
    const sortOptions = { [sortField]: sortDirection };

    // Fetch filtered tasks
    const tasks = await Task.find(query).sort(sortOptions);

    // Compute overall statistics
    const [totalCount, completedCount, pendingCount] = await Promise.all([
      Task.countDocuments({}),
      Task.countDocuments({ completed: true }),
      Task.countDocuments({ completed: false })
    ]);

    res.status(200).json({
      success: true,
      count: tasks.length,
      stats: {
        total: totalCount,
        completed: completedCount,
        pending: pendingCount
      },
      data: tasks
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get a single task by ID
 * @route   GET /api/tasks/:id
 * @access  Public
 */
const getTaskById = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: `Invalid task ID format: "${id}". Must be a valid 24-character hexadecimal ID.`
      });
    }

    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({
        success: false,
        error: `Task not found with ID: ${id}`
      });
    }

    res.status(200).json({
      success: true,
      data: task
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Create a new task
 * @route   POST /api/tasks
 * @access  Public
 */
const createTask = async (req, res, next) => {
  try {
    const { title, description, priority, dueDate } = req.body;

    // Validate required title
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Task title is required and cannot be empty.'
      });
    }

    // Validate priority if provided
    const validPriorities = ['Low', 'Medium', 'High'];
    if (priority && !validPriorities.includes(priority)) {
      return res.status(400).json({
        success: false,
        error: `Invalid priority "${priority}". Allowed values: ${validPriorities.join(', ')}.`
      });
    }

    // Parse dueDate if provided
    let parsedDueDate = null;
    if (dueDate) {
      const d = new Date(dueDate);
      if (isNaN(d.getTime())) {
        return res.status(400).json({
          success: false,
          error: 'Invalid due date format. Please provide a valid date string.'
        });
      }
      parsedDueDate = d;
    }

    const task = await Task.create({
      title: title.trim(),
      description: description ? description.trim() : '',
      priority: priority || 'Medium',
      dueDate: parsedDueDate,
      completed: false
    });

    res.status(201).json({
      success: true,
      message: 'Task created successfully.',
      data: task
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((val) => val.message);
      return res.status(400).json({
        success: false,
        error: messages.join(' ')
      });
    }
    next(error);
  }
};

/**
 * @desc    Update an existing task
 * @route   PUT /api/tasks/:id
 * @access  Public
 */
const updateTask = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: `Invalid task ID format: "${id}".`
      });
    }

    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({
        success: false,
        error: `Task not found with ID: ${id}`
      });
    }

    const { title, description, priority, dueDate, completed } = req.body;

    // Validate title if present
    if (title !== undefined) {
      if (typeof title !== 'string' || title.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Task title cannot be empty.'
        });
      }
      task.title = title.trim();
    }

    // Validate and update description
    if (description !== undefined) {
      task.description = typeof description === 'string' ? description.trim() : '';
    }

    // Validate and update priority
    if (priority !== undefined) {
      const validPriorities = ['Low', 'Medium', 'High'];
      if (!validPriorities.includes(priority)) {
        return res.status(400).json({
          success: false,
          error: `Invalid priority "${priority}". Allowed values: ${validPriorities.join(', ')}.`
        });
      }
      task.priority = priority;
    }

    // Validate and update dueDate
    if (dueDate !== undefined) {
      if (dueDate === null || dueDate === '') {
        task.dueDate = null;
      } else {
        const d = new Date(dueDate);
        if (isNaN(d.getTime())) {
          return res.status(400).json({
            success: false,
            error: 'Invalid due date format.'
          });
        }
        task.dueDate = d;
      }
    }

    // Update completed if provided
    if (completed !== undefined) {
      task.completed = Boolean(completed);
    }

    const updatedTask = await task.save();

    res.status(200).json({
      success: true,
      message: 'Task updated successfully.',
      data: updatedTask
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((val) => val.message);
      return res.status(400).json({
        success: false,
        error: messages.join(' ')
      });
    }
    next(error);
  }
};

/**
 * @desc    Toggle or set task completion status
 * @route   PATCH /api/tasks/:id/complete
 * @access  Public
 */
const toggleTaskCompletion = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: `Invalid task ID format: "${id}".`
      });
    }

    const task = await Task.findById(id);

    if (!task) {
      return res.status(404).json({
        success: false,
        error: `Task not found with ID: ${id}`
      });
    }

    // If request body explicitly specifies completed, use that; otherwise toggle
    if (req.body && typeof req.body.completed === 'boolean') {
      task.completed = req.body.completed;
    } else {
      task.completed = !task.completed;
    }

    const updatedTask = await task.save();

    res.status(200).json({
      success: true,
      message: `Task marked as ${updatedTask.completed ? 'completed' : 'pending'}.`,
      data: updatedTask
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete a task
 * @route   DELETE /api/tasks/:id
 * @access  Public
 */
const deleteTask = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        error: `Invalid task ID format: "${id}".`
      });
    }

    const task = await Task.findByIdAndDelete(id);

    if (!task) {
      return res.status(404).json({
        success: false,
        error: `Task not found with ID: ${id}`
      });
    }

    res.status(200).json({
      success: true,
      message: 'Task deleted successfully.',
      data: {
        id: task._id,
        title: task.title
      }
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  toggleTaskCompletion,
  deleteTask
};
