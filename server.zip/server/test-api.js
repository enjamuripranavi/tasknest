/**
 * TaskNest Automated Integration Test Suite
 * Tests all required REST API endpoints, validation, and database operations.
 */

const assert = require('assert');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '../.env') });
dotenv.config({ path: path.join(__dirname, '../../.env') });

// Set test environment if not already defined
process.env.NODE_ENV = process.env.NODE_ENV || 'test';

const { app } = require('./src/server');
const { connectDB, disconnectDB } = require('./src/config/db');

async function runTests() {
  console.log('🧪 Starting TaskNest API Integration Tests...\n');

  // Initialize DB connection first
  const conn = await connectDB();
  assert.strictEqual(conn.connection.name, 'tasknest', 'Connected database must be "tasknest"');
  console.log(`   Connected Database: ${conn.connection.name} (Verified: isolated from other databases)\n`);

  let server;
  const PORT = 5055; // Use dedicated port for test runner

  await new Promise((resolve) => {
    server = app.listen(PORT, resolve);
  });

  const BASE_URL = `http://localhost:${PORT}`;

  try {
    // 1. Health check
    console.log('1. Testing GET /api/health...');
    const healthRes = await fetch(`${BASE_URL}/api/health`);
    assert.strictEqual(healthRes.status, 200);
    const healthData = await healthRes.json();
    assert.strictEqual(healthData.status, 'ok');
    assert.ok(healthData.database);
    assert.strictEqual(healthData.database.connected, true);
    console.log(`   ✅ Health check passed. Status: "${healthData.database.label}"`);

    // 2. Validate empty title rejection (POST /api/tasks)
    console.log('2. Testing POST /api/tasks with empty title (Validation check)...');
    const badPostRes = await fetch(`${BASE_URL}/api/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '   ', priority: 'High' })
    });
    assert.strictEqual(badPostRes.status, 400);
    const badPostData = await badPostRes.json();
    assert.strictEqual(badPostData.success, false);
    console.log('   ✅ Empty title properly rejected with 400.');

    // 3. Create a valid task
    console.log('3. Testing POST /api/tasks (Create task)...');
    const postRes = await fetch(`${BASE_URL}/api/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Complete MongoDB Atlas Integration',
        description: 'Verify connection string, indexes, and CRUD operations',
        priority: 'High',
        dueDate: '2026-11-20'
      })
    });
    assert.strictEqual(postRes.status, 201);
    const postData = await postRes.json();
    assert.strictEqual(postData.success, true);
    assert.strictEqual(postData.data.title, 'Complete MongoDB Atlas Integration');
    assert.strictEqual(postData.data.priority, 'High');
    assert.strictEqual(postData.data.completed, false);
    const createdTaskId = postData.data._id;
    console.log(`   ✅ Task created successfully. ID: ${createdTaskId}`);

    // Create a second task for list/filtering tests
    await fetch(`${BASE_URL}/api/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Review Responsive Mobile CSS',
        description: 'Test layout on mobile and tablet viewport widths',
        priority: 'Low',
        dueDate: '2026-11-25'
      })
    });

    // 4. Retrieve all tasks (GET /api/tasks)
    console.log('4. Testing GET /api/tasks (Retrieve all tasks & stats)...');
    const getRes = await fetch(`${BASE_URL}/api/tasks`);
    assert.strictEqual(getRes.status, 200);
    const getData = await getRes.json();
    assert.strictEqual(getData.success, true);
    assert.ok(getData.data.length >= 2);
    assert.ok(getData.stats.total >= 2);
    console.log(`   ✅ Retrieved ${getData.data.length} tasks. Total stats: ${getData.stats.total}`);

    // 5. Retrieve single task (GET /api/tasks/:id)
    console.log(`5. Testing GET /api/tasks/${createdTaskId} (Retrieve task by ID)...`);
    const getSingleRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}`);
    assert.strictEqual(getSingleRes.status, 200);
    const getSingleData = await getSingleRes.json();
    assert.strictEqual(getSingleData.data._id, createdTaskId);
    assert.strictEqual(getSingleData.data.title, 'Complete MongoDB Atlas Integration');
    console.log('   ✅ Single task retrieval verified.');

    // 6. Test invalid ID handling
    console.log('6. Testing GET /api/tasks/not-a-valid-id (Invalid ID error handling)...');
    const invalidIdRes = await fetch(`${BASE_URL}/api/tasks/not-a-valid-id`);
    assert.strictEqual(invalidIdRes.status, 400);
    console.log('   ✅ Invalid ObjectId correctly returns 400.');

    // 7. Toggle completion (PATCH /api/tasks/:id/complete)
    console.log(`7. Testing PATCH /api/tasks/${createdTaskId}/complete (Toggle completion)...`);
    const completeRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}/complete`, {
      method: 'PATCH'
    });
    assert.strictEqual(completeRes.status, 200);
    const completeData = await completeRes.json();
    assert.strictEqual(completeData.data.completed, true);
    console.log('   ✅ Task completion status toggled to true.');

    // Toggle back to pending
    const reopenRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}/complete`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: false })
    });
    const reopenData = await reopenRes.json();
    assert.strictEqual(reopenData.data.completed, false);
    console.log('   ✅ Task completion status toggled back to false.');

    // 8. Update task (PUT /api/tasks/:id)
    console.log(`8. Testing PUT /api/tasks/${createdTaskId} (Update task)...`);
    const putRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Complete MongoDB Atlas & Express Integration',
        priority: 'Medium'
      })
    });
    assert.strictEqual(putRes.status, 200);
    const putData = await putRes.json();
    assert.strictEqual(putData.data.title, 'Complete MongoDB Atlas & Express Integration');
    assert.strictEqual(putData.data.priority, 'Medium');
    console.log('   ✅ Task updated successfully.');

    // 9. Search and filtering test
    console.log('9. Testing search and filter query parameters...');
    const searchRes = await fetch(`${BASE_URL}/api/tasks?search=Express&priority=Medium`);
    const searchData = await searchRes.json();
    assert.ok(searchData.data.some((t) => t._id === createdTaskId));
    console.log('   ✅ Search and filter query returned matched task.');

    // 10. Delete task (DELETE /api/tasks/:id)
    console.log(`10. Testing DELETE /api/tasks/${createdTaskId} (Delete task)...`);
    const deleteRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}`, {
      method: 'DELETE'
    });
    assert.strictEqual(deleteRes.status, 200);
    const deleteData = await deleteRes.json();
    assert.strictEqual(deleteData.success, true);
    console.log('   ✅ Task deleted successfully.');

    // Verify task is gone
    const checkDeletedRes = await fetch(`${BASE_URL}/api/tasks/${createdTaskId}`);
    assert.strictEqual(checkDeletedRes.status, 404);
    console.log('   ✅ Deleted task confirmed 404 Not Found.');

    // 11. Test Frontend Static Asset Serving
    console.log('11. Testing Static Frontend Asset Serving (GET /)...');
    const indexRes = await fetch(`${BASE_URL}/`);
    assert.strictEqual(indexRes.status, 200);
    const indexHtml = await indexRes.text();
    assert.ok(indexHtml.includes('TaskNest'));
    console.log('   ✅ Frontend index.html served correctly.');

    console.log('\n🎉 ALL 11 INTEGRATION TESTS PASSED WITH 100% SUCCESS!\n');
  } finally {
    server.close();
    await disconnectDB();
  }
}

runTests().catch((err) => {
  console.error('\n❌ Test execution failed:', err);
  process.exit(1);
});
