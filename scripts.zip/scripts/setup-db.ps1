[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

# Determine absolute paths
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $scriptDir) {
    $scriptDir = $PSScriptRoot
}
$projectRoot = Split-Path -Parent $scriptDir

$envFilePath = Join-Path $projectRoot ".env"
$serverEnvPath = Join-Path $projectRoot "server\.env"
$gitignorePath = Join-Path $projectRoot ".gitignore"
$verifyScriptPath = Join-Path $scriptDir "verify-connection.js"

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "  TaskNest Secure MongoDB Atlas Configuration" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "This utility securely updates your .env file without echoing your"
Write-Host "connection string or saving credentials to your command history."
Write-Host ""

# 1. Verify .gitignore covers .env
if (Test-Path $gitignorePath) {
    $gitignoreContent = Get-Content $gitignorePath -Raw
    if ($gitignoreContent -match '\.env') {
        Write-Host "[OK] Verified: .env is strictly ignored by Git (.gitignore)." -ForegroundColor Green
    } else {
        Write-Host "[WARNING] .env was not found in .gitignore. Adding exclusion now..." -ForegroundColor Yellow
        Add-Content $gitignorePath "`n.env`nserver/.env`n*.env`n"
    }
}

# 2. Prompt securely for connection string (input is masked)
Write-Host ""
Write-Host "Enter your MongoDB Atlas connection string below." -ForegroundColor Yellow
Write-Host "(Input is masked and will NOT be visibly echoed while typing/pasting)" -ForegroundColor Gray
Write-Host ""

$secureString = Read-Host "Paste your MongoDB Atlas connection string" -AsSecureString

if ($null -eq $secureString -or $secureString.Length -eq 0) {
    Write-Host ""
    Write-Host "[ERROR] No connection string provided. Configuration cancelled." -ForegroundColor Red
    exit 1
}

# 3. In-memory conversion and normalization of SecureString
$bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureString)
$rawConnStr = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
[System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

$trimmedConnStr = $rawConnStr.Trim()

# Automatically strip leading "MONGODB_URI=" or "export MONGODB_URI=" if user copied the full key-value line
$trimmedConnStr = $trimmedConnStr -replace '^(?:export\s+|set\s+)?MONGODB_URI\s*=\s*', ''

# Strip leading and trailing quotes (single quotes, double quotes, backticks, spaces)
$trimmedConnStr = $trimmedConnStr.Trim('"', "'", '`', ' ')

# If user pasted a full command e.g. mongosh "mongodb+srv://..."
if ($trimmedConnStr -match 'mongodb(?:\+srv)?:\/\/[^\s"'']+') {
    $trimmedConnStr = $matches[0]
}

if (-not ($trimmedConnStr.StartsWith("mongodb://") -or $trimmedConnStr.StartsWith("mongodb+srv://"))) {
    Write-Host ""
    Write-Host "[ERROR] Connection string must start with 'mongodb://' or 'mongodb+srv://'." -ForegroundColor Red
    Write-Host "Received input did not contain a valid MongoDB connection string." -ForegroundColor Yellow
    Write-Host "Please ensure you paste your connection string, e.g.:" -ForegroundColor Gray
    Write-Host "mongodb+srv://<username>:<password>@buildemployeessystem.xxxx.mongodb.net/tasknest?retryWrites=true&w=majority" -ForegroundColor Gray
    $rawConnStr = $null
    $trimmedConnStr = $null
    $secureString = $null
    [System.GC]::Collect()
    exit 1
}

# 4. Ensure database name is explicitly 'tasknest'
# This isolates TaskNest from your existing Employee Management System database
$adjustedConnStr = $trimmedConnStr
if ($trimmedConnStr -match '^((?:mongodb(?:\+srv)?):\/\/[^\/?]+)(?:\/[^\?]*)?(\?.*)?$') {
    $clusterPart = $matches[1]
    $queryPart = '?retryWrites=true&w=majority'
    if ($matches[2]) {
        $queryPart = $matches[2]
    }
    $adjustedConnStr = $clusterPart + '/tasknest' + $queryPart
}

# 5. Read and update the .env file preserving existing variables
$lines = @()
if (Test-Path $envFilePath) {
    $lines = Get-Content $envFilePath
}

$found = $false
$newLines = @()

foreach ($line in $lines) {
    if ($line -match '^\s*MONGODB_URI\s*=') {
        $newLines += "MONGODB_URI=$adjustedConnStr"
        $found = $true
    } else {
        $newLines += $line
    }
}

if (-not $found) {
    $newLines += "MONGODB_URI=$adjustedConnStr"
}

# Write to root .env
Set-Content -Path $envFilePath -Value $newLines -Encoding utf8

# Also keep server/.env in sync if directory exists
$serverDir = Split-Path -Parent $serverEnvPath
if (Test-Path $serverDir) {
    Set-Content -Path $serverEnvPath -Value $newLines -Encoding utf8
}

Write-Host ""
Write-Host "[SUCCESS] Successfully saved MONGODB_URI to: $envFilePath" -ForegroundColor Green
Write-Host "[CONFIGURED] Database set to: tasknest (preserving Employee Management System database)" -ForegroundColor Green

# 6. Clear sensitive in-memory variables immediately
$rawConnStr = $null
$trimmedConnStr = $null
$adjustedConnStr = $null
$secureString = $null
[System.GC]::Collect()

Write-Host ""
Write-Host "Verifying MongoDB connection now..." -ForegroundColor Cyan

# 7. Run connection test via standalone node script (no inline JS parsing)
Push-Location $projectRoot
try {
    node $verifyScriptPath
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "[SUCCESS] MongoDB Atlas is fully connected and ready!" -ForegroundColor Green
        Write-Host "Run 'npm start' to launch the TaskNest application." -ForegroundColor Green
    } else {
        Write-Host ""
        Write-Host "[FAILED] Connection test failed. Please verify your Atlas credentials or IP whitelist." -ForegroundColor Yellow
    }
} finally {
    Pop-Location
}
