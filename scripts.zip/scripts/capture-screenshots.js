/**
 * TaskNest Automated Screenshot Capturer
 * Uses puppeteer-core and installed Google Chrome to capture real application screenshots.
 */

const path = require('path');
const puppeteer = require('puppeteer-core');
const Task = require('../server/src/models/Task');
const { app } = require('../server/src/server');
const { connectDB, disconnectDB } = require('../server/src/config/db');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const SCREENSHOT_DIR = path.resolve(__dirname, '../screenshots');
const PORT = 5056;

// Seed tasks
const seedData = [
  {
    title: 'Set up MongoDB Atlas & Mongoose Schemas',
    description: 'Configure MongoDB Atlas cluster, connection strings, error handlers, and Task model with validation.',
    priority: 'High',
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // In 2 days
    completed: true
  },
  {
    title: 'Develop Express.js RESTful API Endpoints',
    description: 'Implement CRUD routes for GET, POST, PUT, PATCH, and DELETE with proper HTTP status codes.',
    priority: 'High',
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    completed: true
  },
  {
    title: 'Design Minimal Pastel UI with CSS3',
    description: 'Craft responsive task dashboard, custom buttons, subtle pastel badges, and modal dialogs.',
    priority: 'Medium',
    dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000),
    completed: false
  },
  {
    title: 'Implement Search, Priority & Status Filters',
    description: 'Support real-time search queries and filtering by All, Pending, Completed, and Priority levels.',
    priority: 'Medium',
    dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    completed: false
  },
  {
    title: 'Submit TaskNest Internship Assignment',
    description: 'Prepare complete GitHub repository with detailed documentation, instructions, and test evidence.',
    priority: 'Low',
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    completed: false
  }
];

async function captureAll() {
  console.log('🚀 Starting Screenshot Generation Pipeline...');

  // 1. Connect to DB and clear existing tasks
  await connectDB();
  await Task.deleteMany({});
  await Task.insertMany(seedData);
  console.log('🌱 Database seeded with realistic tasks.');

  // 2. Start server
  let server;
  await new Promise((resolve) => {
    server = app.listen(PORT, resolve);
  });
  console.log(`🌐 Application running at http://localhost:${PORT}`);

  // 3. Launch Chrome
  const browser = await puppeteer.launch({
    executablePath: CHROME_PATH,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu']
  });

  const page = await browser.newPage();
  page.on('console', (msg) => console.log('PAGE LOG:', msg.text()));
  page.on('pageerror', (err) => console.error('PAGE ERROR:', err.message));
  await page.setViewport({ width: 1280, height: 860, deviceScaleFactor: 2 });

  const appUrl = `http://localhost:${PORT}`;

  try {
    // -----------------------------------------------------------------
    // Screenshot 1: Main Dashboard
    // -----------------------------------------------------------------
    console.log('📸 1. Capturing 1-main-dashboard.png...');
    await page.goto(appUrl, { waitUntil: 'networkidle0' });
    await page.waitForSelector('.task-card');
    await new Promise((r) => setTimeout(r, 600)); // Allow animations to settle
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '1-main-dashboard.png'),
      fullPage: false
    });

    // -----------------------------------------------------------------
    // Screenshot 2: Adding a New Task
    // -----------------------------------------------------------------
    console.log('📸 2. Capturing 2-add-task.png...');
    await page.focus('#task-title');
    await page.type('#task-title', 'Conduct Mobile Cross-Browser Responsiveness Review', { delay: 15 });
    await page.click('.priority-high');
    await page.type('#task-due-date', '2026-11-28');
    await page.type('#task-description', 'Verify seamless layout on mobile viewports, iPhone Safari, and Android Chrome.', { delay: 10 });
    await new Promise((r) => setTimeout(r, 400));
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '2-add-task.png'),
      fullPage: false
    });

    // Submit the task to add it to the list
    await page.click('#btn-add-task');
    await new Promise((r) => setTimeout(r, 800));

    // -----------------------------------------------------------------
    // Screenshot 3: Task List with Multiple Tasks
    // -----------------------------------------------------------------
    console.log('📸 3. Capturing 3-task-list.png...');
    // Scroll slightly to feature the rich task list
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '3-task-list.png'),
      fullPage: false
    });

    // -----------------------------------------------------------------
    // Screenshot 4: Editing a Task
    // -----------------------------------------------------------------
    console.log('📸 4. Capturing 4-edit-task.png...');
    // Click the first edit button
    const firstEditBtn = await page.$('.action-btn-edit');
    if (firstEditBtn) {
      await firstEditBtn.click();
      await page.waitForSelector('#edit-modal:not(.hidden)');
      await new Promise((r) => setTimeout(r, 500));
      await page.screenshot({
        path: path.join(SCREENSHOT_DIR, '4-edit-task.png'),
        fullPage: false
      });
      // Close modal
      await page.click('#btn-cancel-edit');
      await page.waitForSelector('#edit-modal.hidden');
      await new Promise((r) => setTimeout(r, 300));
    }

    // -----------------------------------------------------------------
    // Screenshot 5: Deleting a Task Confirmation
    // -----------------------------------------------------------------
    console.log('📸 5. Capturing 5-delete-confirmation.png...');
    const firstDeleteBtn = await page.$('.action-btn-delete');
    if (firstDeleteBtn) {
      await firstDeleteBtn.click();
      await page.waitForSelector('#delete-modal:not(.hidden)');
      await new Promise((r) => setTimeout(r, 500));
      await page.screenshot({
        path: path.join(SCREENSHOT_DIR, '5-delete-confirmation.png'),
        fullPage: false
      });
      // Cancel deletion to keep list intact
      await page.click('#btn-cancel-delete');
      await page.waitForSelector('#delete-modal.hidden');
      await new Promise((r) => setTimeout(r, 300));
    }

    // -----------------------------------------------------------------
    // Screenshot 6: Completed Tasks Filter
    // -----------------------------------------------------------------
    console.log('📸 6. Capturing 6-completed-tasks.png...');
    await page.click('.tab-btn[data-filter="completed"]');
    await new Promise((r) => setTimeout(r, 600));
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '6-completed-tasks.png'),
      fullPage: false
    });

    // Return to all tasks
    await page.click('.tab-btn[data-filter="all"]');
    await new Promise((r) => setTimeout(r, 400));

    // -----------------------------------------------------------------
    // Screenshot 7: Search and Filter Functionality
    // -----------------------------------------------------------------
    console.log('📸 7. Capturing 7-search-filter.png...');
    await page.focus('#search-input');
    await page.type('#search-input', 'MongoDB', { delay: 20 });
    await page.select('#priority-filter', 'High');
    await new Promise((r) => setTimeout(r, 600));
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '7-search-filter.png'),
      fullPage: false
    });

    // Clear search
    await page.click('#btn-clear-search');
    await page.select('#priority-filter', 'all');
    await new Promise((r) => setTimeout(r, 400));

    // -----------------------------------------------------------------
    // Screenshot 8: Mobile Responsive Interface
    // -----------------------------------------------------------------
    console.log('📸 8. Capturing 8-mobile-responsive.png...');
    // Set mobile viewport (iPhone 14 / modern device)
    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 });
    await page.goto(appUrl, { waitUntil: 'networkidle0' });
    await page.waitForSelector('.task-card');
    await new Promise((r) => setTimeout(r, 600));
    await page.screenshot({
      path: path.join(SCREENSHOT_DIR, '8-mobile-responsive.png'),
      fullPage: false
    });

    console.log('\n🎉 ALL 8 ACTUAL APPLICATION SCREENSHOTS CAPTURED SUCCESSFULLY!');
  } finally {
    await browser.close();
    server.close();
    await disconnectDB();
  }
}

captureAll().catch((err) => {
  console.error('Screenshot capture failed:', err);
  process.exit(1);
});
