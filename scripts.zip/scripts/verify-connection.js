/**
 * TaskNest Database Connection Verifier
 * Securely verifies MongoDB Atlas connectivity without exposing credentials.
 */

const path = require('path');
const dotenv = require('dotenv');

// Load environment variables from project root and server directory
dotenv.config({ path: path.resolve(__dirname, '../.env') });
dotenv.config({ path: path.resolve(__dirname, '../server/.env') });

const { connectDB, disconnectDB } = require('../server/src/config/db');

// Redact any password pattern from output messages
const sanitize = (msg) => {
  if (!msg || typeof msg !== 'string') return '';
  return msg.replace(/(mongodb(?:\+srv)?:\/\/[^:]+:)([^@]+)(@)/gi, '$1****$3');
};

async function verify() {
  try {
    const conn = await connectDB();
    console.log('✅ Connection Test: SUCCESSFUL');
    console.log(`   Cluster Host   : ${conn.connection.host}`);
    console.log(`   Active Database: ${conn.connection.name}`);
    await disconnectDB();
    process.exit(0);
  } catch (err) {
    console.error('❌ Connection Test: FAILED');
    console.error(`   ${sanitize(err.message)}`);
    process.exit(1);
  }
}

verify();
